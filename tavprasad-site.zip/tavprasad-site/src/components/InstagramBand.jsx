import { site } from '../data/siteConfig'

export default function InstagramBand() {
  return (
    <a className="igband" href={site.instagramUrl} target="_blank" rel="noreferrer" aria-label={`Follow ${site.name} on Instagram`}>
      <span className="igband__small">New drops, behind the scenes and customer fits</span>
      <span className="igband__big">Follow @{site.instagramHandle}</span>
      <span className="igband__arrow" aria-hidden="true">↗</span>
    </a>
  )
}
