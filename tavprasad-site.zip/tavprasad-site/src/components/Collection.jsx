import { useState } from 'react'
import { products, filters } from '../data/products'
import ProductCard from './ProductCard'
import Reveal from './Reveal'

export default function Collection() {
  const [active, setActive] = useState('all')
  const visible = active === 'all' ? products : products.filter((p) => p.category === active)

  return (
    <section className="section" id="shop">
      <div className="container">
        <Reveal className="section__head">
          <p className="eyebrow">The collection</p>
          <h2 className="section__title">Heritage &amp; Mindset</h2>
          <p className="section__sub">
            Two sides of the same brand: pieces honouring Khalsa history, and prints that keep your head clear and your
            energy protected.
          </p>
        </Reveal>

        <div className="filters" role="tablist" aria-label="Filter products">
          {filters.map((f) => (
            <button
              key={f.id}
              role="tab"
              aria-selected={active === f.id}
              className={`filters__btn ${active === f.id ? 'is-active' : ''}`}
              onClick={() => setActive(f.id)}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="grid">
          {visible.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
