import { useState } from 'react'
import { site } from '../data/siteConfig'
import { whatsappLink } from '../lib/contact'
import Reveal from './Reveal'

const topics = ['Order an existing design', 'Custom print', 'Bulk / team order', 'Something else']

export default function Contact() {
  const [form, setForm] = useState({ name: '', topic: topics[1], message: '' })
  const [status, setStatus] = useState('')

  const update = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }))

  const submit = async (e) => {
    e.preventDefault()
    const text = `Hi TavPrasad! I'm ${form.name}.\nTopic: ${form.topic}\n${form.message}`
    if (site.whatsapp) {
      window.open(whatsappLink(text), '_blank', 'noopener')
      setStatus('Opening WhatsApp…')
      return
    }
    // Instagram can't be pre-filled, so copy the message and open the DM.
    try {
      await navigator.clipboard.writeText(text)
      setStatus('Message copied. Paste it into the Instagram DM that just opened.')
    } catch {
      setStatus('Instagram DM opened. Please type your message there.')
    }
    window.open(site.instagramDm, '_blank', 'noopener')
  }

  return (
    <section className="section" id="contact">
      <div className="container contact">
        <Reveal className="contact__info">
          <p className="eyebrow">Contact</p>
          <h2 className="section__title">Let’s make something.</h2>
          <p className="section__sub">
            Questions about sizes, a custom idea, or a bulk order? Send us a message and we’ll get back to you.
          </p>
          <ul className="contact__list">
            <li>
              <span>Instagram</span>
              <a href={site.instagramUrl} target="_blank" rel="noreferrer">@{site.instagramHandle}</a>
            </li>
            {site.whatsapp && (
              <li>
                <span>WhatsApp</span>
                <a href={whatsappLink('Hi TavPrasad!')} target="_blank" rel="noreferrer">Chat with us</a>
              </li>
            )}
            {site.email && (
              <li>
                <span>Email</span>
                <a href={`mailto:${site.email}`}>{site.email}</a>
              </li>
            )}
          </ul>
        </Reveal>

        <Reveal as="form" className="form" delay={120} onSubmit={submit}>
          <label>
            Your name
            <input name="name" value={form.name} onChange={update} required autoComplete="name" placeholder="Your name" />
          </label>
          <label>
            I’m interested in
            <select name="topic" value={form.topic} onChange={update}>
              {topics.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </label>
          <label>
            Tell us more
            <textarea
              name="message"
              rows="5"
              value={form.message}
              onChange={update}
              required
              placeholder="Design idea, size, quantity, timeline…"
            />
          </label>
          <button className="btn btn--lime" type="submit">
            {site.whatsapp ? 'Send on WhatsApp' : 'Send on Instagram'}
          </button>
          <p className="form__status" role="status" aria-live="polite">{status}</p>
        </Reveal>
      </div>
    </section>
  )
}
