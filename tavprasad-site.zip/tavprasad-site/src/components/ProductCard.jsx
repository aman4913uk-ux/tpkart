import { orderLink, orderLabel } from '../lib/contact'
import Reveal from './Reveal'

export default function ProductCard({ product, index }) {
  const { name, tag, blurb, image, hoverImage, display, hoverDisplay, price } = product
  return (
    <Reveal as="article" className="card" delay={(index % 3) * 90}>
      <div className="card__media">
        <img
          className={`card__img card__img--main card__img--${display}`}
          src={image}
          alt={name}
          loading="lazy"
        />
        {hoverImage && (
          <img
            className={`card__img card__img--hover card__img--${hoverDisplay || display}`}
            src={hoverImage}
            alt=""
            loading="lazy"
          />
        )}
        <span className="card__tag">{tag}</span>
      </div>
      <div className="card__body">
        <h3 className="card__name">{name}</h3>
        <p className="card__blurb">{blurb}</p>
        <div className="card__foot">
          <span className="card__price">{price || 'Limited drop'}</span>
          <a className="btn btn--lime btn--sm" href={orderLink(product)} target="_blank" rel="noreferrer">
            {orderLabel}
          </a>
        </div>
      </div>
    </Reveal>
  )
}
