const words = [
  'Wear your roots',
  'ਪੰਜਾਬੀ ਵਿਰਸਾ',
  'Khalsa pride',
  'Protect your energy',
  'Custom prints',
  'Change your mind',
]

export default function Marquee() {
  const row = words.map((w, i) => (
    <span key={i} className={/[\u0A00-\u0A7F]/.test(w) ? 'pa' : ''}>
      {w}
      <i aria-hidden="true">✦</i>
    </span>
  ))
  return (
    <div className="marquee" aria-hidden="true">
      <div className="marquee__track">
        <div className="marquee__row">{row}</div>
        <div className="marquee__row">{row}</div>
      </div>
    </div>
  )
}
