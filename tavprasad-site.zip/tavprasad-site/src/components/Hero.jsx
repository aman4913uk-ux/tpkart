import armyOfGod from '../assets/army-of-god.webp'
import avoidBadCompany from '../assets/avoid-bad-company.webp'
import logo from '../assets/logo.webp'

export default function Hero() {
  return (
    <section className="hero" id="top">
      <div className="container hero__grid">
        <div className="hero__copy">
          <p className="eyebrow">
            <span className="pa">ਪੰਜਾਬੀ ਵਿਰਸਾ</span> · Punjabi heritage streetwear
          </p>
          <h1 className="hero__title">
            <span>Wear your roots.</span>
            <span className="hero__title--lime">Wear your mind.</span>
          </h1>
          <p className="hero__lead">
            Custom graphic hoodies and tees celebrating Punjabi culture, Sikh heritage and everyday motivation. Bold
            prints for people who carry their story with pride.
          </p>
          <div className="hero__cta">
            <a className="btn btn--lime" href="#shop">Shop the collection</a>
            <a className="btn btn--ghost" href="#custom">Get a custom print</a>
          </div>
          <ul className="hero__facts">
            <li>Premium graphic hoodies &amp; tees</li>
            <li>Custom prints on request</li>
            <li>Keeping Punjabi alive in fashion</li>
          </ul>
        </div>

        <div className="hero__visual" aria-hidden="false">
          <img className="hero__badge" src={logo} alt="TavPrasad logo" width="120" height="120" />
          <figure className="hero__card hero__card--a">
            <img src={armyOfGod} alt="Black Army of God Khalsa hoodie rotating" width="360" height="640" />
          </figure>
          <figure className="hero__card hero__card--b">
            <img src={avoidBadCompany} alt="White Avoid Bad Company hoodie rotating" width="360" height="640" />
          </figure>
        </div>
      </div>
    </section>
  )
}
