import Reveal from './Reveal'
import artDeepSingh from '../assets/art-deepsingh.webp'

const pillars = [
  {
    n: '01',
    title: 'Heritage',
    text: 'Bold pieces honouring Khalsa history, made to be worn with pride, not hidden away.',
  },
  {
    n: '02',
    title: 'Mindset',
    text: 'Motivational prints that remind you to stay focused and protect your energy.',
  },
  {
    n: '03',
    title: 'Punjabi language',
    text: 'We’re committed to keeping Punjabi alive by carrying it into modern fashion.',
    pa: 'ਪੰਜਾਬੀ',
  },
]

export default function Story() {
  return (
    <section className="section section--navy" id="story">
      <div className="container story">
        <Reveal className="story__copy">
          <p className="eyebrow">Our story</p>
          <h2 className="section__title">
            Wear your culture.
            <br />
            Inspire your circle.
          </h2>
          <p className="story__text">
            TavPrasad is a custom streetwear and apparel brand celebrating Punjabi culture, Sikh heritage and everyday
            motivation. We design and print premium graphic hoodies, T-shirts and custom clothing that let you wear your
            roots and your mindset with pride.
          </p>
          <p className="story__text">
            From bold heritage pieces honouring Khalsa history to striking motivational prints, every design is crafted to
            make a statement.
          </p>

          <ul className="pillars">
            {pillars.map((p) => (
              <li key={p.n} className="pillars__item">
                <span className="pillars__n">{p.n}</span>
                <div>
                  <h3>
                    {p.title} {p.pa && <span className="pa pillars__pa">{p.pa}</span>}
                  </h3>
                  <p>{p.text}</p>
                </div>
              </li>
            ))}
          </ul>
        </Reveal>

        <Reveal className="story__visual" delay={120}>
          <div className="story__glow" aria-hidden="true" />
          <img src={artDeepSingh} alt="A Man Defeats Death: Dhan Baba Deep Singh Ji artwork" loading="lazy" />
        </Reveal>
      </div>
    </section>
  )
}
