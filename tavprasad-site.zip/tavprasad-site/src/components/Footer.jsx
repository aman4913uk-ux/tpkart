import logo from '../assets/logo.webp'
import { site } from '../data/siteConfig'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__inner">
        <div className="footer__brand">
          <img src={logo} alt="" width="64" height="64" />
          <div>
            <strong>TAVPRASAD</strong>
            <p>
              <span className="pa">ਤਵ ਪ੍ਰਸਾਦ</span> · Wear your roots.
            </p>
          </div>
        </div>
        <nav className="footer__links" aria-label="Footer">
          <a href="#shop">Shop</a>
          <a href="#story">Our Story</a>
          <a href="#custom">Custom Prints</a>
          <a href="#contact">Contact</a>
          <a href={site.instagramUrl} target="_blank" rel="noreferrer">Instagram</a>
        </nav>
      </div>
      <p className="footer__copy">© {new Date().getFullYear()} TavPrasad. All rights reserved.</p>
    </footer>
  )
}
