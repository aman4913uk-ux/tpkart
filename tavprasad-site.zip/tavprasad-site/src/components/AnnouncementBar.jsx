import { site } from '../data/siteConfig'

export default function AnnouncementBar() {
  return (
    <div className="announce">
      <p>
        Custom prints open: DM <a href={site.instagramUrl} target="_blank" rel="noreferrer">@{site.instagramHandle}</a> to start your design
      </p>
    </div>
  )
}
