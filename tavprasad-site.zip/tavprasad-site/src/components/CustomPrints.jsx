import Reveal from './Reveal'
import blackHoodie from '../assets/blank-black-hoodie.webp'
import greyHoodie from '../assets/blank-grey-hoodie.webp'
import acidTee from '../assets/blank-acid-tee.webp'
import whiteTee from '../assets/blank-white-tee.webp'

const steps = [
  { n: '1', title: 'Share your idea', text: 'Send a design, a logo, a quote or just a rough concept on Instagram or WhatsApp.' },
  { n: '2', title: 'Pick your piece', text: 'Choose a hoodie or tee from the blanks below, plus your size and fit.' },
  { n: '3', title: 'We design & print', text: 'We refine the artwork with you, then print it on premium apparel.' },
  { n: '4', title: 'Wear it', text: 'Your one-of-one piece, ready to wear your story.' },
]

const blanks = [
  { src: blackHoodie, label: 'Black fleece hoodie' },
  { src: greyHoodie, label: 'Heather grey hoodie' },
  { src: acidTee, label: 'Acid wash tee' },
  { src: whiteTee, label: 'Off-white tee' },
]

export default function CustomPrints() {
  return (
    <section className="section section--navy" id="custom">
      <div className="container">
        <Reveal className="section__head">
          <p className="eyebrow">Custom prints</p>
          <h2 className="section__title">Your design. Our print.</h2>
          <p className="section__sub">
            For your crew, your team, your event or just you. Bring the idea, we’ll turn it into something you’re proud
            to wear.
          </p>
        </Reveal>

        <ol className="steps">
          {steps.map((s, i) => (
            <Reveal as="li" key={s.n} className="steps__item" delay={i * 80}>
              <span className="steps__n">{s.n}</span>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
            </Reveal>
          ))}
        </ol>

        <Reveal className="blanks">
          <h3 className="blanks__title">Pieces you can print on</h3>
          <div className="blanks__grid">
            {blanks.map((b) => (
              <figure key={b.label} className="blanks__item">
                <img src={b.src} alt={b.label} loading="lazy" />
                <figcaption>{b.label}</figcaption>
              </figure>
            ))}
          </div>
          <div className="blanks__cta">
            <a className="btn btn--lime" href="#contact">Start a custom order</a>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
