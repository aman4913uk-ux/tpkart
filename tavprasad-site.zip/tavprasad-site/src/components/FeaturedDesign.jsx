import Reveal from './Reveal'
import mindFront from '../assets/mind-front.webp'
import mindBack from '../assets/mind-back.webp'

export default function FeaturedDesign() {
  return (
    <section className="section feature">
      <div className="container feature__grid">
        <Reveal className="feature__photos">
          <img className="feature__photo feature__photo--front" src={mindFront} alt="Mind Control hoodie, front print" loading="lazy" />
          <img className="feature__photo feature__photo--back" src={mindBack} alt="Mind Control hoodie, back print with kitten and lion mirror" loading="lazy" />
        </Reveal>

        <Reveal className="feature__copy" delay={120}>
          <p className="eyebrow">Featured design</p>
          <h2 className="section__title">Mind Control</h2>
          <blockquote className="feature__quote">
            If you can change your <em>Mind</em>,
            <br />
            you can change your <em>Life</em>.
          </blockquote>
          <p className="story__text">
            The front shows a brain wired into the feed. The back shows who you really are: a lion in the mirror. One
            hoodie, a reminder to take your attention back.
          </p>
          <div className="hero__cta">
            <a className="btn btn--lime" href="#contact">Ask about this hoodie</a>
            <a className="btn btn--ghost" href="#shop">See all designs</a>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
