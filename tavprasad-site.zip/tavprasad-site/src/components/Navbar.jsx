import { useEffect, useState } from 'react'
import logo from '../assets/logo.webp'
import { site } from '../data/siteConfig'

const links = [
  { href: '#shop', label: 'Shop' },
  { href: '#story', label: 'Our Story' },
  { href: '#custom', label: 'Custom Prints' },
  { href: '#contact', label: 'Contact' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header className={`nav ${scrolled ? 'nav--scrolled' : ''} ${open ? 'nav--open' : ''}`}>
      <div className="container nav__inner">
        <a href="#top" className="nav__brand" aria-label="TavPrasad home">
          <img src={logo} alt="" width="48" height="48" />
          <span className="nav__name">TAVPRASAD</span>
        </a>

        <nav className="nav__links" aria-label="Primary">
          {links.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)}>{l.label}</a>
          ))}
        </nav>

        <a className="btn btn--lime btn--sm nav__cta" href={site.instagramUrl} target="_blank" rel="noreferrer">
          Instagram
        </a>

        <button
          className="nav__toggle"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span /><span /><span />
        </button>
      </div>
    </header>
  )
}
