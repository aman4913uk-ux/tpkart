import AnnouncementBar from './components/AnnouncementBar'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import Marquee from './components/Marquee'
import Collection from './components/Collection'
import Story from './components/Story'
import FeaturedDesign from './components/FeaturedDesign'
import CustomPrints from './components/CustomPrints'
import InstagramBand from './components/InstagramBand'
import Contact from './components/Contact'
import Footer from './components/Footer'

export default function App() {
  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <AnnouncementBar />
      <Navbar />
      <main id="main">
        <Hero />
        <Marquee />
        <Collection />
        <Story />
        <FeaturedDesign />
        <CustomPrints />
        <InstagramBand />
        <Contact />
      </main>
      <Footer />
    </>
  )
}
