// Edit this file to update contact details and links across the whole site.
export const site = {
  name: 'TavPrasad',
  instagramHandle: 'tpkart1326',
  instagramUrl: 'https://www.instagram.com/tpkart1326/',
  instagramDm: 'https://ig.me/m/tpkart1326',

  // Optional. Add your WhatsApp number with country code and no "+" or spaces,
  // e.g. '919876543210'. When set, "Order" buttons and the enquiry form open a
  // WhatsApp chat with a pre-filled message. When empty, they open Instagram DMs.
  whatsapp: '',

  // Optional. Shown in the contact section and footer when set.
  email: '',
}
