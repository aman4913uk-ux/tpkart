import armyOfGod from '../assets/army-of-god.webp'
import avoidBadCompany from '../assets/avoid-bad-company.webp'
import artKhalsa from '../assets/art-khalsa.webp'
import artDeepSingh from '../assets/art-deepsingh.webp'
import artMind from '../assets/art-mind.webp'
import mindFront from '../assets/mind-front.webp'
import mindBack from '../assets/mind-back.webp'

// To show a price, set `price: 'Rs. 2,499'`. Leave it null to show "Limited drop".
// `display: 'photo'` fills the card with the image; `'art'` floats a print on a dark stage.
export const products = [
  {
    id: 'army-of-god',
    name: 'Army of God Khalsa Hoodie',
    category: 'heritage',
    tag: 'Heritage',
    blurb: 'Twin lions guard the Khanda inside a bold Khalsa emblem.',
    image: armyOfGod,
    hoverImage: artKhalsa,
    display: 'photo',
    price: null,
  },
  {
    id: 'baba-deep-singh',
    name: 'A Man Defeats Death: Baba Deep Singh Ji',
    category: 'heritage',
    tag: 'Heritage',
    blurb: 'A tribute to the warrior-saint, in gold and smoke.',
    image: artDeepSingh,
    display: 'art',
    price: null,
  },
  {
    id: 'mind-control',
    name: 'Mind Control Hoodie',
    category: 'mindset',
    tag: 'Mindset',
    blurb: 'Your brain on the feed. Take it back.',
    image: mindFront,
    hoverImage: artMind,
    hoverDisplay: 'art',
    display: 'photo',
    price: null,
  },
  {
    id: 'change-your-mind',
    name: 'Change Your Mind Hoodie (Back Print)',
    category: 'mindset',
    tag: 'Mindset',
    blurb: 'A kitten, a mirror, a lion. Change your mind, change your life.',
    image: mindBack,
    display: 'photo',
    price: null,
  },
  {
    id: 'avoid-bad-company',
    name: 'Avoid Bad Company Hoodie',
    category: 'mindset',
    tag: 'Mindset',
    blurb: 'Protect your energy. Choose your circle.',
    image: avoidBadCompany,
    display: 'photo',
    price: null,
  },
]

export const filters = [
  { id: 'all', label: 'All' },
  { id: 'heritage', label: 'Heritage' },
  { id: 'mindset', label: 'Mindset' },
]
